﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Global : MonoBehaviour {
    public static int score = 0;
    public static int multiplier = 1;
    public static float timer = 0;
    public static float timeLimit= 2;
    public static bool gameOver = false;
    public static bool gameStarted = false;

}
